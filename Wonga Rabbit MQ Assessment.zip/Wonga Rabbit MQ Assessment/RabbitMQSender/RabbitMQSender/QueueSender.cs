﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RabbitMQSender
{
    public class QueueSender
    {
        public static void Publish(IModel channel)
        {
            channel.QueueDeclare("rabbitMQ-queue",
                 durable: true,
                 exclusive: false,
                 autoDelete: false,
                 arguments: null);

            while (true)
            { 
                Console.WriteLine("Please Enter Name");
                string name = Console.ReadLine();

                var message = new { Name = "Sender", message = "Hello My Name Is, " + " " + name };
                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));

                channel.BasicPublish("", "rabbitMQ-queue", null, body);
                Thread.Sleep(1000);



            }

        }
    }
}
