﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using System;
using System.Text;

namespace RabbitMQSender
{
    static class Program
    {
        static void Main(string[] args)
        {
            var connectionFactory = new ConnectionFactory
            {
                Uri = new Uri("amqp://guest@localhost:5672")
            
            };

            using var connection = connectionFactory.CreateConnection();
            using var channel = connection.CreateModel();
            QueueSender.Publish(channel);


        }
    }
}
