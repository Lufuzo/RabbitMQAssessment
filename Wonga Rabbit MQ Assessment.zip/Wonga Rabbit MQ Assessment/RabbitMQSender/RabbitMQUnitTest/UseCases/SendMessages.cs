﻿using NUnit.Framework;
using RabbitMQ.Client;
using RabbitMQ.Fakes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RabbitMQUnitTest.UseCases
{
    [TestFixture]
    public class SendMessages
    {
        [Test]
        public void SendToExchangeOnly()
        {
            var rabbitServer = new RabbitServer();
            var connectionFactory = new FakeConnectionFactory(rabbitServer);

            using (var connection = connectionFactory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                
                const string message =  "Hello My Name Is! LUNGELO ";
                var messageBody = Encoding.ASCII.GetBytes(message);
                channel.BasicPublish(exchange: "mq-exchange", routingKey: null, mandatory: false, basicProperties: null, body: messageBody);
            }

            Assert.That(rabbitServer.Exchanges["mq-exchange"].Messages.Count, Is.EqualTo(1));
        }
        [Test]
        public void SendToExchangeWithBoundQueue()
        {
            var rabbitServer = new RabbitServer();
            var connectionFactory = new FakeConnectionFactory(rabbitServer);

            ConfigureQueueBinding(rabbitServer, "mq-exchange", "rabbitMQ-queue");

            using (var connection = connectionFactory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                const string message = "Hello My Name Is! LUNGELO ";
                var messageBody = Encoding.ASCII.GetBytes(message);
                channel.BasicPublish(exchange: "mq-exchange", routingKey: null, mandatory: false, basicProperties: null, body: messageBody);
            }

            Assert.That(rabbitServer.Queues["mq-exchange"].Messages.Count, Is.EqualTo(1));
        }
        private void ConfigureQueueBinding(RabbitServer rabbitServer, string exchangeName, string queueName)
        {
            var connectionFactory = new FakeConnectionFactory(rabbitServer);
            using (var connection = connectionFactory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.QueueDeclare(queue: queueName, durable: false, exclusive: false, autoDelete: false, arguments: null);
                channel.ExchangeDeclare(exchange: exchangeName, type: ExchangeType.Direct);

                channel.QueueBind(queueName, exchangeName, null);
            }
        }

    }
}
