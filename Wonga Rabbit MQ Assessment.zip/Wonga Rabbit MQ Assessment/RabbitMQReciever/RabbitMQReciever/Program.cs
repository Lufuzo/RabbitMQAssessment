﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;

namespace RabbitMQReciever
{
    static class Program
    {
        static void Main(string[] args)
        {
            var connectionFactory = new ConnectionFactory()
            {
                Uri = new Uri("amqp://guest@localhost:5672")

            };

            using var connection = connectionFactory.CreateConnection();
            using var channel = connection.CreateModel();

            QueueReciever.Publish(channel);


        }
    }
}
